###############
# Description #
###############

Python Poker is a game of Texas Hold ’em written in Python. It’s just a classic game of Texas Hold ‘em starting with a table of 8 players. There is the opportunity to play multiplayer, but to start with, there will be 7 bots at the table who decide on how to play based on an equation or multiple equations based on the situation.

##############
# How to Run #
##############

The user runs __init__.py to play. There are no data/source files to set up.

#############
# Libraries #
#############

No external libraries were used.

#####################
# Shortcut Commands #
#####################

The game and settings are simple enough to not require shortcut commands.